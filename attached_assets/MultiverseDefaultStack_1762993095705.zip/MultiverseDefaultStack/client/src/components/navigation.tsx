import React from "react";
import {
  NavigationRoot,
  NavigationMenu,
  NavigationMenuGroup,
  NavigationMenuItem,
  NavigationMenuItemIconProps,
  HomeIcon,
  NavigationPageContent,
  CodeIcon,
  HeaderRoot,
} from "@multiverse-io/stardust-react";
import { Link } from "wouter";

function NavigationLayout({ children }: { children: React.ReactNode }) {
  return (
    <NavigationRoot>
      <NavigationMenu>
        <NavigationMenuGroup>
          {/* Example navigation options */}
          {/* <NavigationMenuItem
            as={Link}
            href="#course1"
            renderIcon={(iconProps: NavigationMenuItemIconProps) => (
              <HomeIcon {...iconProps} />
            )}
            active={true}
          >
            Home
          </NavigationMenuItem>
          <NavigationMenuItem
            as={Link}
            href="/components"
            renderIcon={(iconProps: NavigationMenuItemIconProps) => (
              <CodeIcon {...iconProps} />
            )}
          >
            Components
          </NavigationMenuItem> */}
        </NavigationMenuGroup>
      </NavigationMenu>
      <HeaderRoot></HeaderRoot>
      <NavigationPageContent>{children}</NavigationPageContent>
    </NavigationRoot>
  );
}

export default NavigationLayout;
