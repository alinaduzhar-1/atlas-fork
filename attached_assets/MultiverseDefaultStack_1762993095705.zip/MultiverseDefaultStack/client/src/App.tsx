import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import NotFound from "@/pages/not-found";
import NavigationLayout from "./components/navigation";
import { EnvironmentIndicator, Toaster } from "@multiverse-io/stardust-react";

function Router() {
  return (
    <Switch>
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <>
      <EnvironmentIndicator label="Internal prototyping only"></EnvironmentIndicator>
      <Toaster />
      <QueryClientProvider client={queryClient}>
        <Router />
      </QueryClientProvider>
    </>
  );
}

export default App;
